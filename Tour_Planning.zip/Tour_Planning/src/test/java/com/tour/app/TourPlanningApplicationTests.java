package com.tour.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TourPlanningApplicationTests {

	@Test
	void contextLoads() {
	}

}

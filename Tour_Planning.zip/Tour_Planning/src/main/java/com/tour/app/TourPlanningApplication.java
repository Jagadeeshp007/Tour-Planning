package com.tour.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TourPlanningApplication {

	public static void main(String[] args) {
		SpringApplication.run(TourPlanningApplication.class, args);
	}

}

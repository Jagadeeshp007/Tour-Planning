export class TourDetail {
    id: number;
    fromPlace: string;
    toPlace: string;
    duration: string;
    hours: string;

}

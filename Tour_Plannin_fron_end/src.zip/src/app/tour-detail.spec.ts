import { TourDetail } from './tour-detail';

describe('TourDetail', () => {
  it('should create an instance', () => {
    expect(new TourDetail()).toBeTruthy();
  });
});
